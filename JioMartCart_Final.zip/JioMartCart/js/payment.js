document.addEventListener('DOMContentLoaded', function() {
    const paymentMethodSelect = document.getElementById('payment_method');
    const cardDetails = document.getElementById('card-details');
    const upiDetails = document.getElementById('upi-details');
    const codDetails = document.getElementById('cod-details');
    const paymentForm = document.getElementById('payment-form');

    paymentMethodSelect.addEventListener('change', function() {
        cardDetails.style.display = 'none';
        upiDetails.style.display = 'none';
        codDetails.style.display = 'none';

        const cardInputs = cardDetails.querySelectorAll('input, select');
        const upiInputs = upiDetails.querySelectorAll('input');

        cardInputs.forEach(input => input.removeAttribute('required'));
        upiInputs.forEach(input => input.removeAttribute('required'));

        if (this.value === 'card') {
            cardDetails.style.display = 'block';
            cardInputs.forEach(input => {
                if (input.id !== 'card_type') {
                    input.setAttribute('required', 'required');
                }
            });
        } else if (this.value === 'upi') {
            upiDetails.style.display = 'block';
            upiInputs.forEach(input => input.setAttribute('required', 'required'));
        } else if (this.value === 'cod') {
            codDetails.style.display = 'block';
        }
    });

    const cardNumberInput = document.getElementById('card_number');
    if (cardNumberInput) {
        cardNumberInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\s/g, '');
            let formattedValue = value.match(/.{1,4}/g)?.join(' ') || value;
            e.target.value = formattedValue;
        });
    }

    const expiryInput = document.getElementById('expiry');
    if (expiryInput) {
        expiryInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length >= 2) {
                value = value.slice(0, 2) + '/' + value.slice(2, 4);
            }
            e.target.value = value;
        });
    }

    const cvvInput = document.getElementById('cvv');
    if (cvvInput) {
        cvvInput.addEventListener('input', function(e) {
            e.target.value = e.target.value.replace(/\D/g, '');
        });
    }

    paymentForm.addEventListener('submit', function(e) {
        const paymentMethod = paymentMethodSelect.value;
        
        if (!paymentMethod) {
            e.preventDefault();
            alert('Please select a payment method');
            return false;
        }

        if (paymentMethod === 'card') {
            const cardNumber = document.getElementById('card_number').value.replace(/\s/g, '');
            const expiry = document.getElementById('expiry').value;
            const cvv = document.getElementById('cvv').value;

            if (cardNumber.length < 13 || cardNumber.length > 19) {
                e.preventDefault();
                alert('Please enter a valid card number');
                return false;
            }

            if (!/^\d{2}\/\d{2}$/.test(expiry)) {
                e.preventDefault();
                alert('Please enter a valid expiry date (MM/YY)');
                return false;
            }

            if (cvv.length !== 3) {
                e.preventDefault();
                alert('Please enter a valid CVV');
                return false;
            }
        } else if (paymentMethod === 'upi') {
            const upiId = document.getElementById('upi_id').value;
            if (!/@/.test(upiId)) {
                e.preventDefault();
                alert('Please enter a valid UPI ID');
                return false;
            }
        }
    });
});
