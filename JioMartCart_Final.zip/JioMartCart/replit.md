# JioMart E-commerce Website

## Overview
A fully functional e-commerce website inspired by JioMart, built with HTML, CSS, JavaScript, and PHP. This website provides a complete online shopping experience including product browsing with search and filtering, shopping cart management, checkout process, multiple payment methods, and order confirmation. The system uses session-based state management with comprehensive security measures.

## Current State
The website is fully operational with all requested features and security measures implemented. The application is ready for use as a demo/learning project.

## Features

### Product Catalog (index.php)
- Grid layout displaying 10 products across different categories (Vegetables, Fruits, Snacks, Breakfast, Dairy)
- Search functionality to find products by name
- Category filtering
- Add to cart functionality with CSRF protection
- Real product images from stock photography
- Responsive design for mobile and desktop

### Shopping Cart (cart.php)
- View all items in cart with product images
- Update item quantities (1-99)
- Remove items from cart
- Automatic cart validation against canonical product data
- Calculate subtotal and delivery charges
- Free delivery for orders above ₹500
- CSRF protection on all cart operations

### Checkout (checkout.php)
- User information form (name, email, phone)
- Delivery address collection with validation
- Server-side validation for all inputs
- Order summary sidebar
- CSRF protection

### Payment (payment.php)
- Multiple payment methods:
  - Credit/Debit Card (Visa, Mastercard, RuPay)
  - UPI
  - Cash on Delivery
- Server-side validation:
  - Card number validation using Luhn algorithm
  - Expiry date format and validity check
  - CVV validation (3 digits)
  - UPI ID format validation
- JavaScript-powered dynamic form fields
- Review delivery address before payment
- CSRF protection

### Order Confirmation (confirmation.php)
- Order confirmation with unique order ID
- Complete order summary with all items
- Delivery information display
- Payment method confirmation
- Print order functionality
- Continue shopping option

## Technology Stack

### Frontend
- HTML5 with semantic markup
- CSS3 with responsive grid layout and flexbox
- Vanilla JavaScript for dynamic interactions
- JioMart-inspired color scheme (blue #0066cc and orange #ff6b00)
- Mobile-responsive design with media queries

### Backend
- PHP 8.2
- Session-based cart management
- Server-side form processing and validation
- CSRF token protection
- Input sanitization
- Canonical product data source

### Security Features
- **CSRF Protection**: All state-changing forms include CSRF tokens
- **Server-Side Validation**: All user inputs validated on the server
- **Canonical Product Data**: Products sourced from products.php and validated
- **Cart Validation**: Invalid product IDs automatically removed
- **Payment Validation**: Luhn algorithm for card numbers, format checks for all fields
- **Session Security**: Session regeneration after payment
- **XSS Prevention**: Input sanitization using htmlspecialchars
- **Quantity Limits**: Cart quantities capped at 99 items

### Images
- 10 stock images for product catalog
- Categories: vegetables, fruits, snacks, breakfast items, dairy products

## Project Structure
```
/
├── index.php           # Main product catalog page
├── cart.php            # Shopping cart page
├── checkout.php        # Checkout and delivery information
├── payment.php         # Payment details
├── confirmation.php    # Order confirmation
├── products.php        # Canonical product data and validation functions
├── css/
│   └── style.css       # Main stylesheet with responsive design
├── js/
│   └── payment.js      # Payment form JavaScript
├── images/             # Product images (10 items)
├── replit.md           # This file
└── .gitignore          # Git ignore file
```

## Recent Changes (Nov 20, 2025)
- Initial project setup and structure
- Installed PHP 8.2 module
- Created all pages (index, cart, checkout, payment, confirmation)
- Implemented responsive CSS styling with JioMart color scheme
- Added JavaScript for payment form validation and dynamic fields
- Downloaded and integrated 10 stock product images
- Configured PHP workflow to run on port 5000
- Created products.php for canonical product data
- Implemented comprehensive security measures:
  - CSRF token protection on all state-changing forms
  - Server-side validation for all user inputs
  - Cart validation against canonical product IDs
  - Payment validation with Luhn algorithm for cards
  - Expiry date, CVV, and UPI format validation
  - Session regeneration after payment
  - Input sanitization to prevent XSS attacks
  - Quantity limits and validation
- Passed security review by architect for demo scope

## User Preferences
- Preferred communication style: Simple, everyday language

## Running the Project
The project runs on PHP's built-in web server on port 5000. The workflow "JioMart Website" is configured to start automatically.

Command: `php -S 0.0.0.0:5000`

## Security Notes
This implementation includes appropriate security measures for a demo/learning e-commerce project:
- All critical security vulnerabilities addressed
- CSRF protection prevents cross-site request forgery
- Server-side validation prevents data tampering
- Canonical product source prevents price manipulation
- Payment validation ensures data integrity

For production use, consider:
- Integration with real payment gateway (Stripe, Razorpay)
- Database for persistent data storage
- User authentication and account system
- HTTPS/SSL encryption
- Enhanced logging and monitoring
- Rate limiting for form submissions

## Future Enhancements
- User account system with order history
- Product reviews and ratings
- Wishlist functionality
- Admin panel for product management
- Email notifications for order confirmations
- Integration with actual payment gateway
- Database integration (MySQL/PostgreSQL)
- Product inventory management
- Order tracking system
- Mobile app version
